PLUGIN = PLUGIN

Clockwork.flag:Add("M", "Free Medical", "Access to medical supplies for free.")