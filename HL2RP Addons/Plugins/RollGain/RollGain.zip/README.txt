Included in this pack:

-Roll gain which replaces the old roll command, so that certain aspects of a character will stack.

=======================
Things to Note:
=======================

Just about everything for the character will stack gain points, which will then be included in the roll. Here are some information on what stacks.

-Attributes

-Equipped Weapon

- What Faction they are in.

- What rank within that faction they are in (MPF and OTA only)

This means you could have a +60 added to your roll, since all of these will stack. If you're an OfC, with a shotgun with a strengh > 10 then all those gains would add up over time. This means while there is still a bit of unpredictably, it allows rolls to be more reliable.

Here are the values.

MPF-RCT  =  No Gain  (Recruits are usually just citizens in some armor.)
MPF-04  =  +5
MPF-03  =  +10
MPF-02  =  +17
MPF-01  =  +20
MPF-OfC  =  +25
MPF-EpU  =  +30
MPF-DvL  =  +35
MPF-SeC  =  +40

OTA-OWS (Standart OTA)  =  +40
OTA-EOW (Elite OTA)  =  +50

Next, attribute gains:
If character has more than 10 strength, he has +10, if he has more than 10 to any other attribute, he has +5 gain.

Next, weapon gains:
Any meelee weapon  =  +5  (Like stunstick)
Pistol  =  +10
.357 Magnum  =  +15
MP7  =  +15
Shotgun  =  +25
AR-2  =  +30
CrossBow  =  +30
RPG  =  Nothing
Grenades  =  Nothing

Factions:
Civil Workers Union  =  +5
MPF (Any other rank)  =  +7
OTA (Any other rank) = +40

================
Bugs:
================

SeC and DvL game seems a bit iffy, it doesn't actually use the values assigned to it sometimes.

================
How to install:
================

Put RollGain in your plugins folder for Clockwork or HL2RP.

================
Problems?
================

If there are any issues feel free to email me at connall@orbiter-gaming.com


Thanks for downloading!

Connall Lindsay
Head of Orbiter Gaming