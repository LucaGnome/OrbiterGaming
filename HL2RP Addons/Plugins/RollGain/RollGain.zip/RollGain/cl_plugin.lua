PLUGIN = PLUGIN

Clockwork.config:AddToSystem("Roll Gain", "roll_gain", "Whether to add a certain amount of numbers based on the conditions of player characters.");