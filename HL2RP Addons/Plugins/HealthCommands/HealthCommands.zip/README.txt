Included in this pack:

-Set Player health Command
-Get Max Health of Player Command
-Set Max Health Command

=======================
Things to Note:
=======================

Not much to note this time around. These commands do not alter max health forever. Upon death they reset I believe.

================
Bugs:
================

No bugs were found, but if you find any, please let me know on the C16 forums or at connall@orbiter-gaming.com

================
How to install:
================

Put HealthCommands in your plugins folder for Clockwork.

================
Problems?
================

If there are any issues feel free to email me at connall@orbiter-gaming.com


Thanks for downloading!

Connall Lindsay
Head of Orbiter Gaming